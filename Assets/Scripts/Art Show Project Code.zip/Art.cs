﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Art : MonoBehaviour {
    public string artName;
    public Sprite artImage;
    public string Description;
    public Transform cameraPosition;
}
